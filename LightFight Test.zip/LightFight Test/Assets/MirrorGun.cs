﻿using UnityEngine;
using System.Collections;
using System;

public class MirrorGun : Tool {

    
    public override void Fire()
    {
        Instantiate(tool, transform.position, transform.rotation);
    }
}
