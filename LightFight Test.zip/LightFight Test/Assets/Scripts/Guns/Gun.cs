﻿using UnityEngine;
using System.Collections;

public abstract class Gun : MonoBehaviour {

    public float fireRate;
    private float nextFire;
    public GameObject shotType;

    public void AttemptFire()
    {
        if (Time.time > nextFire)
        {
            nextFire = Time.time + fireRate;
            Fire();
        }
    }

    public abstract void Fire();
}
