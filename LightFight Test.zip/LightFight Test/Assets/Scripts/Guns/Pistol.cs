﻿using UnityEngine;
using System.Collections;

public class Pistol : Gun {

    override public void Fire()
    {
        // Makes a bullet (Fucking Gasp)
        Instantiate(shotType, transform.position, transform.rotation);
    }
}
