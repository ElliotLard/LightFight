﻿using UnityEngine;
using System.Collections;

public class PlayerBehavior : MonoBehaviour {

	// How fast the player will move when they move.
	public float speed;

	// Gives us access to the RB2D, so we can move the player.
	private Rigidbody2D rb2d;
    public Gun gunType;
    public Tool toolType;
	public Transform firePoint;

    private Gun leGun;
    private Tool leTool; 
	void Start()
	{
		rb2d = GetComponent<Rigidbody2D> ();
        leGun = Instantiate(gunType, firePoint.position, transform.rotation) as Gun;
        leGun.transform.parent = transform;
        leTool = Instantiate(toolType, firePoint.position, transform.rotation) as Tool;
        leTool.transform.parent = transform;
	}

	void Update()
	{
        if (Input.GetMouseButton(0))
        {
            leGun.AttemptFire();
        }

        if (Input.GetMouseButton(1))
        {
            leTool.AttemptFire();
        }
	}

	void FixedUpdate()
	{
		// Move with physics
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");

		Vector2 movement = new Vector2 (moveHorizontal, moveVertical);
		rb2d.velocity = (movement * speed);
		// Rotate to Face the Mouse
		Vector3 pos = Camera.main.WorldToScreenPoint (transform.position);
		Vector3 dir = Input.mousePosition - pos;
		float angle = Mathf.Atan2 (dir.y, dir.x) * Mathf.Rad2Deg - 90;
		transform.rotation = Quaternion.AngleAxis (angle, Vector3.forward);
	}
}
