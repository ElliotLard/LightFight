﻿using UnityEngine;
using System.Collections;
// Ideally this will contain behavior for an unlocked camera, if one wants that.
public class UnlockedCamera : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 pos = Camera.main.WorldToViewportPoint(Input.mousePosition);
 //     if (pos.x < 0)
	}
}
